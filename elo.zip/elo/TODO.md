
# Extras
* Drop down name textboxes in update.php
* Paginate table
* Sortable table columns
* Sort modal list in order of most to least sets played
* Improve CSS